INSERT INTO hospedes (nome, cpf, email, telefone, nascimento) VALUES ('Ana Paula Souza', '11122233344', 'ana.souza@email.com', '11987654321', '1988-03-15');

INSERT INTO hospedes (nome, cpf, email, telefone, nascimento) VALUES ('Bruno Carvalho', '22233344455', 'bruno.carvalho@email.com', '11976543210', '1975-07-22');

INSERT INTO hospedes (nome, cpf, email, telefone, nascimento) VALUES ('Carla Mendes', '33344455566', 'carla.mendes@email.com', '21965432109', '1992-11-05');

INSERT INTO hospedes (nome, cpf, email, telefone, nascimento) VALUES ('Diego Ferreira', '44455566677', 'diego.ferreira@email.com', '31954321098', '1983-01-30');

INSERT INTO hospedes (nome, cpf, email, telefone, nascimento) VALUES ('Elisa Rocha', '55566677788', 'elisa.rocha@email.com', '41943210987', '1999-09-12');

INSERT INTO dependentes (hospede_id, nome, cpf, nascimento) VALUES (1, 'Lucas Souza', '66677788899', '2015-06-10');

INSERT INTO dependentes (hospede_id, nome, cpf, nascimento) VALUES (1, 'Marina Souza', '77788899900', '2018-02-25');

INSERT INTO dependentes (hospede_id, nome, cpf, nascimento) VALUES (2, 'Pedro Carvalho', '88899900011', '2010-12-03');

INSERT INTO dependentes (hospede_id, nome, cpf, nascimento) VALUES (4, 'Julia Ferreira', '99900011122', '2012-04-18');

INSERT INTO funcionarios (nome, cpf, rg, nacionalidade, telefone, email, endereco, cargo, departamento, nivel_acesso, observacoes, foto_base64, nascimento, contratacao, salario) VALUES ('Roberto Lima', '12312312312', '123456789', 'Brasileira', '11911112222', 'roberto.lima@vesta.com', 'Rua das Flores, 100 - São Paulo/SP', 'Gerente', 'Administração', 'ADMIN', 'Responsável geral pelo hotel', NULL, '1980-05-20', '2015-03-01', 8500.00);

INSERT INTO funcionarios (nome, cpf, rg, nacionalidade, telefone, email, endereco, cargo, departamento, nivel_acesso, observacoes, foto_base64, nascimento, contratacao, salario) VALUES ('Fernanda Alves', '23423423423', '234567890', 'Brasileira', '11922223333', 'fernanda.alves@vesta.com', 'Av. Paulista, 1500 - São Paulo/SP', 'Recepcionista', 'Recepção', 'RECEPCAO', NULL, NULL, '1995-08-14', '2021-06-15', 2800.00);

INSERT INTO funcionarios (nome, cpf, rg, nacionalidade, telefone, email, endereco, cargo, departamento, nivel_acesso, observacoes, foto_base64, nascimento, contratacao, salario) VALUES ('Marcos Oliveira', '34534534534', '345678901', 'Brasileira', '11933334444', 'marcos.oliveira@vesta.com', 'Rua Augusta, 300 - São Paulo/SP', 'Camareiro', 'Governança', 'OPERACIONAL', 'Trabalha no turno da manhã', NULL, '1990-02-10', '2019-09-01', 2200.00);

INSERT INTO funcionarios (nome, cpf, rg, nacionalidade, telefone, email, endereco, cargo, departamento, nivel_acesso, observacoes, foto_base64, nascimento, contratacao, salario) VALUES ('Sofia Martinez', '45645645645', '456789012', 'Argentina', '11944445555', 'sofia.martinez@vesta.com', 'Rua Oscar Freire, 50 - São Paulo/SP', 'Recepcionista', 'Recepção', 'RECEPCAO', 'Fala espanhol e inglês', NULL, '1993-11-25', '2023-01-10', 3000.00);

INSERT INTO dependencias (identificacao, tipo, localizacao, status, tipo_quarto, moveis, acessibilidade, observacoes, capacidade, quantidade_camas) VALUES ('Quarto 101', 'Quarto', '1º andar', 'Disponível', 'Standard', 'Cama de casal, frigobar, TV', 'Não', NULL, 2, 1);

INSERT INTO dependencias (identificacao, tipo, localizacao, status, tipo_quarto, moveis, acessibilidade, observacoes, capacidade, quantidade_camas) VALUES ('Quarto 102', 'Quarto', '1º andar', 'Ocupado', 'Standard', '2 camas de solteiro, frigobar, TV', 'Sim', 'Adaptado para cadeirantes', 2, 2);

INSERT INTO dependencias (identificacao, tipo, localizacao, status, tipo_quarto, moveis, acessibilidade, observacoes, capacidade, quantidade_camas) VALUES ('Quarto 201', 'Quarto', '2º andar', 'Disponível', 'Luxo', 'Cama king, banheira, frigobar, TV', 'Não', 'Vista para o mar', 2, 1);

INSERT INTO dependencias (identificacao, tipo, localizacao, status, tipo_quarto, moveis, acessibilidade, observacoes, capacidade, quantidade_camas) VALUES ('Quarto 202', 'Quarto', '2º andar', 'Manutenção', 'Família', 'Cama de casal, 2 camas de solteiro, TV', 'Não', 'Ar-condicionado em conserto', 4, 3);

INSERT INTO dependencias (identificacao, tipo, localizacao, status, tipo_quarto, moveis, acessibilidade, observacoes, capacidade, quantidade_camas) VALUES ('Salão de Eventos', 'Área comum', 'Térreo', 'Disponível', NULL, 'Mesas, cadeiras, projetor', 'Sim', NULL, 80, 0);

INSERT INTO dependencias (identificacao, tipo, localizacao, status, tipo_quarto, moveis, acessibilidade, observacoes, capacidade, quantidade_camas) VALUES ('Piscina', 'Área comum', 'Térreo', 'Disponível', NULL, 'Espreguiçadeiras, guarda-sóis', 'Sim', 'Funciona das 8h às 20h', 30, 0);

INSERT INTO reservas (checkin, checkout, quantidade_pessoas, cpf, quarto_tipo, camas, pagamento_forma, pagamento_status) VALUES ('2026-11-02', '2026-11-05', 3, '11122233344', 'Família', '1 casal + 1 solteiro', 'Cartão de crédito', 'Pago');

INSERT INTO reservas (checkin, checkout, quantidade_pessoas, cpf, quarto_tipo, camas, pagamento_forma, pagamento_status) VALUES ('2026-11-10', '2026-11-12', 2, '22233344455', 'Standard', '2 solteiro', 'Pix', 'Pendente');

INSERT INTO reservas (checkin, checkout, quantidade_pessoas, cpf, quarto_tipo, camas, pagamento_forma, pagamento_status) VALUES ('2026-12-20', '2026-12-27', 2, '33344455566', 'Luxo', '1 king', 'Cartão de crédito', 'Pago');

INSERT INTO reservas (checkin, checkout, quantidade_pessoas, cpf, quarto_tipo, camas, pagamento_forma, pagamento_status) VALUES ('2026-11-15', '2026-11-16', 1, '55566677788', 'Standard', '1 casal', 'Dinheiro', 'Pendente');

INSERT INTO reservas (checkin, checkout, quantidade_pessoas, cpf, quarto_tipo, camas, pagamento_forma, pagamento_status) VALUES ('2026-10-20', '2026-10-23', 2, '44455566677', 'Standard', '1 casal', 'Pix', 'Pago');