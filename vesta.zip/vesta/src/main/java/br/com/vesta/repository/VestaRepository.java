package br.com.vesta.repository;

public interface VestaRepository {

}
