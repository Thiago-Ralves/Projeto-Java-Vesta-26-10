package br.com.vesta.model;

import java.time.LocalDate;
import jakarta.persistence.*;

@Entity                        
@Table(name = "hospedes")      
public class Hospede {

    @Id                                                   
    @GeneratedValue(strategy = GenerationType.IDENTITY)   
    private Long id;

    private String nome;
    private String cpf;
    private String email;
    private String telefone;
    private LocalDate nascimento;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public LocalDate getNascimento() {
		return nascimento;
	}
	public void setNascimento(LocalDate nascimento) {
		this.nascimento = nascimento;
	}
    
    
}