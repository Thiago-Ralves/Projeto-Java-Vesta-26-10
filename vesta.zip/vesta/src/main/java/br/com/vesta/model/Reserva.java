package br.com.vesta.model;

import java.time.LocalDate;
import jakarta.persistence.*;

@Entity
@Table(name = "reservas")
public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate checkin;
    private LocalDate checkout;
    private Integer quantidadePessoas;

    private String cpf;
    private String quartoTipo;
    private String camas;
    private String pagamentoForma;
    private String pagamentoStatus;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public LocalDate getCheckin() {
		return checkin;
	}
	public void setCheckin(LocalDate checkin) {
		this.checkin = checkin;
	}
	public LocalDate getCheckout() {
		return checkout;
	}
	public void setCheckout(LocalDate checkout) {
		this.checkout = checkout;
	}
	public Integer getQuantidadePessoas() {
		return quantidadePessoas;
	}
	public void setQuantidadePessoas(Integer quantidadePessoas) {
		this.quantidadePessoas = quantidadePessoas;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getQuartoTipo() {
		return quartoTipo;
	}
	public void setQuartoTipo(String quartoTipo) {
		this.quartoTipo = quartoTipo;
	}
	public String getCamas() {
		return camas;
	}
	public void setCamas(String camas) {
		this.camas = camas;
	}
	public String getPagamentoForma() {
		return pagamentoForma;
	}
	public void setPagamentoForma(String pagamentoForma) {
		this.pagamentoForma = pagamentoForma;
	}
	public String getPagamentoStatus() {
		return pagamentoStatus;
	}
	public void setPagamentoStatus(String pagamentoStatus) {
		this.pagamentoStatus = pagamentoStatus;
	}
    
    
}