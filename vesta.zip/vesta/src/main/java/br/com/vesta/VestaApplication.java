package br.com.vesta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VestaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VestaApplication.class, args);
	}

}
